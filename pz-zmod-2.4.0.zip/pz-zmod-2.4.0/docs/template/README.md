# ZomboidMod

[![release](https://img.shields.io/github/v/release/cocolabs/pz-zmod)](https://github.
com/cocolabs/pz-zmod/releases/latest) ![Game Version](https://img.shields.io/badge/PZ%20Version-IWBUMS%3A%2041.47-red) [![License](https://img.shields.io/github/license/yooksi/pz-zmod)](https://mit-license.org/) [![chat](https://img.shields.io/discord/717757483376050203?color=7289DA&label=discord&logo=discord&logoColor=white)](https://discord.gg/vCeydWCbd9)

Short description of what this mod is all about.

> **TODO:** remember to update badge links to point to your mod repository.

## Motivation

A short description of the motivation behind the creation of this mod.

## Screenshots

Show everyone how great your mod is.

## Features

Write about things that make this mod great.

## Installation

- Download the [latest release](https://github.com/yooksi/pz-zmod/releases/latest) from the repository releases section.
- Unpack the release with your preferred file archiver[<sup>?</sup>](a "rar, zip, 7zip, etc.") to game mod directory.
- Start the game and toggle the mod in the Mod-Options screen.

For more information read [How To Install / Uninstall Mods](https://theindiestone.com/forums/index.php?/topic/1395-how-to-install-uninstall-mods/) forum thread.

> **TODO**: remember to update link to `latest release` to point to your repository.

## How to use
Explain different ways in which your mod can be used in-game.

## Credits

Give proper credits to those that helped make this project.

## License

MIT © [Yourname](https://github.com/cocolabs)

> **TODO**: remember to update copyright text to apply the license to your project.
> Read more information on how to do this [here](https://github.com/cocolabs/pz-zmod#license).